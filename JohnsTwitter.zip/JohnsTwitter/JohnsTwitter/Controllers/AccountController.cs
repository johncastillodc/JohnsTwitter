﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using JohnsTwitter.Models;

namespace JohnsTwitter.Controllers;

/// <summary>
///	account controller class
/// </summary>
public class AccountController : Controller
{
	private readonly UserManager<IdentityUser> userManager;
	private readonly SignInManager<IdentityUser> signInManager;

	public AccountController(UserManager<IdentityUser> userManager,
		SignInManager<IdentityUser> signInManager)
	{
		this.userManager = userManager;
		this.signInManager = signInManager;
	}

	/// <summary>
	/// This is the Register method
	/// </summary>
	/// <returns></returns>
	[HttpGet]
	public IActionResult Register()
	{
		return View();
	}

	/// <summary>
	/// Register method
	/// </summary>
	/// <param name="model"></param>
	/// <returns></returns>
	[HttpPost]
	public async Task<IActionResult> Register(RegisterViewModel model)
	{
		if (ModelState.IsValid)
		{
			var user = new IdentityUser
			{
				UserName = model.Email,
				Email = model.Email
			};

			var result = await userManager.CreateAsync(user, model.Password);
			if (result.Succeeded)
			{
				await signInManager.SignInAsync(user, isPersistent: false);
				return RedirectToAction("Index", "Home");
			}

			foreach (var error in result.Errors)
			{
				ModelState.TryAddModelError(string.Empty, error.Description);
			}
		}
		return View(model);
	}

	/// <summary>
	/// This is the Login method
	/// </summary>
	/// <returns></returns>
	[HttpGet]
	public IActionResult Login()
	{
		return View();
	}

	/// <summary>
	/// This is the Login method
	/// </summary>
	/// <param name="model"></param>
	/// <returns></returns>
	[HttpPost]
	public async Task<IActionResult> Login(LoginViewModel model)
	{
		if (ModelState.IsValid)
		{
			var result = await signInManager.PasswordSignInAsync(
			model.Email, model.Password, model.RememberMe, false);
			if (result.Succeeded)
			{
				return RedirectToAction("Index", "Users"); //redirect to the Feed page after login
			}
			ModelState.AddModelError(string.Empty, "Invalid Login");
		}

		return View(model);
	}

	/// <summary>
	/// logout method
	/// </summary>
	/// <returns></returns>
	[HttpPost] 
	public async Task<IActionResult> Logout()
	{
		await signInManager.SignOutAsync();
		//redirect to the Home page after logout
		return RedirectToAction("Index", "Home"); 
	}
}