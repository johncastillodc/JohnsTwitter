﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using System.Net.Mail;
using JohnsTwitter.Entities;
using static System.Net.Mime.MediaTypeNames;

namespace JohnsTwitter.Context
{
    public class AppDbContext : IdentityDbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) :
            base(options)
        { }
        public DbSet<User> Users { get; set; }

        //protected override void OnModelCreating(ModelBuilder modelBuilder)
        //{
        //    base.OnModelCreating(modelBuilder); //adding a data once the app is run
        //    modelBuilder.Entity<User>().HasData
        //    (new User
        //    {
        //        UserId = 1,
        //        Name = "John",
        //        EmailAddress = "john@email.com",
        //        Bio = "I work for Dell",
        //        Tweet = "I'm working today",
        //        Comment = "Nice",
        //    });
        //}
    }
}
