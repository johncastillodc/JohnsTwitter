﻿using System.ComponentModel.DataAnnotations;

namespace JohnsTwitter.Entities
{
    public class User
    {
        public int UserId { get; set; }

        [Required, MaxLength(20, ErrorMessage = "Name cannot exceed 20 characters")]
        public string Name { get; set; }

        [EmailAddress]
        [Required, MaxLength(40)]
        public string EmailAddress { get; set; }

        [Required, MaxLength(100, ErrorMessage = "Bio must be 100 characters or less")]
        public string Bio { get; set; }

        [Required, MaxLength(100, ErrorMessage = "Tweet cannot exceed 20 characters")]
        public string Tweet { get; set; }

        [Required, MaxLength(100, ErrorMessage = "Comment cannot exceed 20 characters")]
        public string Comment { get; set; }
    }
}